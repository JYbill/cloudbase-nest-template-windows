/* eslint-disable */
const main = require('./dist/main')

exports.tcbGetApp = main.bootstrap
